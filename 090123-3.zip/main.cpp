
//===== Begin code area ============================================================================================================

#include <stdio.h>
#include <cstring>
#include <iostream>
using namespace std;

extern "C" void comparing();

int main(){

  comparing();


  return 0;

}//End of main
//=======1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**
