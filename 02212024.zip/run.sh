#!/bin/bash


rm *.o
rm *.out

nasm -f elf64 -o manager.o manager.asm

nasm -f elf64 -o theother.o theother.asm

nasm -f elf64 -o isfloat.o isfloat.asm

g++ -c -m64 -Wall -o main.o main.cpp -fno-pie -no-pie -std=c++20

g++ -m64 -o output.out manager.o theother.o main.o isfloat.o -fno-pie -no-pie -std=c++20

./output.out

