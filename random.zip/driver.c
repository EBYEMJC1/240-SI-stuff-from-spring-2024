//****************************************************************************************************************************
//Program name: "Amazing Triangles".  This program solves the third side of a prompted triangle inputted by the user
//  Copyright (C) 2024  Aaron Haight.
//                                                                                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.  This program is distributed in the hope that it will be useful,   *
//but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See   *
//the GNU General Public License for more details A copy of the GNU General Public License v3 is available here:             *
//<https://www.gnu.org/licenses/>.                                                                                           *
//****************************************************************************************************************************

//Author: Aaron Haight
//Author email: aaronmhaight@csu.fullerton.edu
//Program name: Amazing Triangles
//Programming languages: One module in C, one in X86, and one in bash.
//Date program began: 2024-Feb-8
//Date of last update: 2024-Feb-8
//Files in this program: driver.c, manager.asm, r.sh.  At a future date rg.sh may be added
//Testing: Alpha testing completed.  All functions are correct.
//Status: Ready for release to the customers

//Purpose of this program:
//  This program solves the third side of a prompted triangle inputted by the user

//This file
//  File name: main.c
//  Language: C language, 202x standardization where x will be a decimal digit.
//  Max page width: 106 columns
//  Compile: gcc -m64 -no-pie -o driver.o -std=c20 -Wall driver.c -c
//  Link: gcc -m64 -no-pie -o manager.out manager.o driver.o -std=c20 -Wall -z noexecstack

#include <stdio.h>
#include <math.h>

extern double compute_triangle();

int main() {
    printf("Welcome to Amazing Triangles programmed by Aaron Haight on February 8, 2024.\n");
    
    double third_side = compute_triangle();

    printf("The driver received this number %.8f and will siply keep it.\n", third_side);
    printf("An integer zero will now be sent to the operating system. Bye\n");

    return 0;
}