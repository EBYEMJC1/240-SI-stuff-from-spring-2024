#!/bin/bash

rm *.o
rm *.out

#Assemble isfloat.asm
nasm -f elf64 -o isfloat.o isfloat.asm

#Assemble source file `manager.asm`
nasm -f elf64 -l mgr.lis -o mgr.o manager.asm

#Compile source file `driver.c`
gcc -m64 -no-pie -std=c2x -o driver.o -c driver.c

#Link the object modules to create an executable file
gcc -m64 -no-pie -std=c2x -o trig.out isfloat.o driver.o mgr.o -lm

#grant all privileges
chmod +x trig.out

#execute
./trig.out
