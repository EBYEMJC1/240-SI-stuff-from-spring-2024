#include <math.h> // cos
#include <stdio.h> //printf

extern double trigIO();

int main( int argc, const char * argv[] )
{
    printf(  "\nWelcome to Amazing Triangles programmed by Isaiah Vogt on February 24, 2024.\n");
    double num = 0.0;
    num = trigIO();
    printf( "\nThe driver received this number %1.6lf and will simply keep it.\n", num );
    printf( "\nAn integer zero will now be sent to the operating system. Bye.\n" );
    return 0;
}
