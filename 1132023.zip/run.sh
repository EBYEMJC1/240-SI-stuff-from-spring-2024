#!/bin/bash


#Author: Floyd Holliday
#Program name: Basic Float Operations

rm *.o
rm *.out
rm *.lis

nasm -f elf64 -l main.lis -o main.o main.asm

nasm -f elf64 -l isfloat.lis -o isfloat.o isfloat.asm

g++ -c -m64 -Wall -o driver.o main.cpp -fno-pie -no-pie -std=c++20

g++ -m64 -o merged.out driver.o main.o isfloat.o -fno-pie -no-pie -std=c++20

./merged.out

