long heat[52];
double wind[40];
chatr city[30];