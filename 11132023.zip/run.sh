#!/bin/bash


#Author: Floyd Holliday
#Program name: Basic Float Operations

rm *.o
rm *.out

nasm -f elf64 -l main_asm.lis -o main_asm.o main.asm -gdwarf

g++ -c -m64 -Wall -o main_cpp.o main.cpp -fno-pie -no-pie -std=c++20 -g

g++ -m64 -o output.out main_asm.o main_cpp.o -fno-pie -no-pie -std=c++20 -g

gdb output.out

