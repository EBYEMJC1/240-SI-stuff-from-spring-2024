//Date program began:
//Date of last update:
//Files in this program: 
//Testing: Alpha testing completed.  All functions are correct.
//Status: Ready for release to the customers

//Purpose of this program:
//  This program is a starting point for those learning to program in x86 assembly

//This file
//  File name: 
//  Language: C language, 202x standardization where x will be a decimal digit.
//  Max page width: 124 columns
//  Compile: gcc -m64 -no-pie -o average.o -std=c20 -Wall driver.c -c
//  Link: gcc -m64 -no-pie -o assignment1.out driver.o average.o -std=c2x -Wall -z noexecstack

#include <stdio.h>
#include <math.h>

extern double compute_triangle();

int main()
{
    printf("Welcome to Amazing Triangles programmed by Kanji Oyama on February 24, 2024\n");
    double count = 0;
    count = compute_triangle();
    printf("The driver has received this number %lf and will simply keep it.\n", count);
    printf("An integer zero will now be sent to the operating system. Bye\n");
    return -1;
}