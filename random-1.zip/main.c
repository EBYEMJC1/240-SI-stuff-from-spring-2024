//****************************************************************************************************************************
//Program name: "Triangles".  This program serves a program that inputs the lengths of two sides of a triangle and inputs    *
// the size of the angle between those two sides.   The length of the third side is computed.  The three input values are    *
// validated by suitable checking mechanism.   Copyright (C) 2024  Miguel Romero Mojica                                      *
//                                                                                                                           *
//This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
//version 3 as published by the Free Software Foundation.  This program is distributed in the hope that it will be useful,   *
//but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See   *
//the GNU General Public License for more details A copy of the GNU General Public License v3 is available here:             *
//<https://www.gnu.org/licenses/>.                                                                                           *
//****************************************************************************************************************************

// Author: Miguel Romero Mojica
// Author email: miguelromerojr10@csu.fullerton.edu
// Author section: 240-11
// Author CWID : 885298885
// Program name: Triangles
// Programming languages: One module in C, one in X86, and one in bash.
// Date program began: 2024-Feb-19
// Date of last update: 2024-Feb-24
// Files in this program: main.c, compute_triangle.asm, r.sh.  At a future date rg.sh may be added
// Testing: Alpha testing completed.  All functions are correct.
// Status: Ready for release to the customers

// Purpose of this program:
//  This program calculates the third side of a triangle using inputs.

// This file
//  File name: main.c
//  Language: C language, 202x standardization where x will be a decimal digit.
//  Max page width: 124 columns
//  Compile: gcc -m64 -no-pie -o main.o -std=c2x -Wall main.c -c
//  Link: gcc -m64 -no-pie -o learn.out triangle.o main.o -std=c2x -Wall -z noexecstack
//  Run:./learn.out

#include <stdio.h>
#include <math.h>

extern double compute_triangle();

int main()
{
    printf("Welcome to Amazing Triangles maintained by Miguel Romero Mojica\n");

    double result = compute_triangle();

    printf("\nThe driver has received this number %.8f and will simply keep it.\n", result);
    printf("An integer zero will now be sent to the operating system.   Bye\n");

    return 0;
}
