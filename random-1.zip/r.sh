#/bin/bash

#Program name "Compute Triangle"
#Author: Miguel Romero Mojica
#This file is the script file that accompanies the "Compute Triangle" program.
#Prepare for execution in normal mode (not gdb mode).

#!/bin/bash

#Delete some un-needed files
rm *.o
rm *.out

echo "Assemble the source file manager.asm"
nasm -f elf64 -l tri.lis -o tri.o compute_triangle.asm

echo "Compile the source file driver.c"
gcc  -m64 -Wall -no-pie -o angle.o -std=c2x -c main.c

echo "Compile the helper file isfloat.asm"
nasm -f elf64 -o isfloat.o isfloat.asm

echo "Link the object modules to create an executable file"
gcc -m64 -no-pie -o triangle.out tri.o angle.o isfloat.o -std=c2x -Wall -z noexecstack -lm

echo "Execute the program that allows triangles to be solved"
chmod +x triangle.out
./triangle.out

echo "This bash script will now terminate."
