#include "stdio.h"

extern void manage_array();

int main(int argc, char* argv[])
{
  manage_array();
}//End of main