#include <cstring>
#include <iostream>

int main() {
  // Create a character array to store the string "hi world"
  char string[] = "hi world";

  // Print the original string
  std::cout << "Original String: " << string << std::endl;
}
