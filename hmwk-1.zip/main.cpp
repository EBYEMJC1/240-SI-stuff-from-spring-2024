
//===== Begin code area ============================================================================================================

#include <stdio.h>
#include <cstring>
#include <iostream>
using namespace std;

extern "C" double avg_speed();

int main(){

  double avg = avg_speed();
  std::cout << "The main module received this number " << avg << " and will keep it for a while\n";
  std::cout << "A zero will be sent to your operating system.\nGood-bye. Have a great trip.\n";


  return 0;

}//End of main
//=======1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3**
